This is a menu program!

Build Procedure
    $ gcc linktable.c menu.c -o menu
    $ ./menu # you can input help, delete, cdup, pwd or version cmd.
