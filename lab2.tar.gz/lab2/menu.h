/**************************************************************************************************/
/* Copyright (C) SoftwareDesign@USTC, 2014                                                        */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Caoyang                                                              */
/*  PRINCIPAL AUTHOR ID   :  JG14225028                                                           */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/12                                                           */
/*  DESCRIPTION           :  Interface of menu.c                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Caoyang, 2014/09/12
 *
 */

#ifndef _MENU_H_
#define _MENU_H_

#include <pthread.h>

#define SUCCESS 0
#define FAILURE (-1)

/* data struct and its operations */

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();
} tDataNode;

/* find a cmd in the linklist and return the datanode pointer */
tDataNode* FindCmd(tLinkTable * head, char * cmd);

/* show all cmd in linklist */
int ShowAllCmd(tLinkTable * head);

/* menu program */
static tDataNode data[];

int Help();

#endif /* _MENU_H_ */

